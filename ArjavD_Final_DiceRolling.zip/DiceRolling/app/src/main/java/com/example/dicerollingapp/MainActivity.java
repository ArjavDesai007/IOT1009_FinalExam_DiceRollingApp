package com.example.dicerollingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private static final String DICE_ROLLING_DATABASE = "DICE_ROLLING_DATABASE";

    private static final String DICE_ONE_POINT = "DICE_ONE_POINT";
    private static final String DICE_TWO_POINT = "DICE_TWO_POINT";

    private static final String DICE_ONE_LAST_POINT = "DICE_ONE_LAST_POINT";
    private static final String DICE_TWO_LAST_POINT = "DICE_TWO_LAST_POINT";

    private static final String MAX_CLICK = "MAX_CLICK";
    private static final String SELECTED_DICE = "SELECTED_DICE";
    private static final String NUMBER_OF_SIDES_FOR_DICE2 = "NUMBER_OF_SIDES_FOR_DICE2";

    private SharedPreferences.Editor editor;

    private TextView txtDiceOne, txtDiceTwo,txtDicePoint1,txtDicePoint2,defaultSide;
    private RadioGroup radioGroup;
    private int selectedDice = 1;

    int Low = 1;
    int High = 12;
    private int maxClick = 0;

    private RadioButton selectedDiceOne,selectedDiceTwo,selectedBoth;
    private EditText diceTwoValue;
    private Integer diceTwoSide = 12;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //big blue box for show dice sides
        txtDiceOne = findViewById(R.id.txtDiceOne);
        txtDiceTwo = findViewById(R.id.txtDiceTwo);

        //Dice 1 and 2 result bottom of three radio buttons
        txtDicePoint1 = findViewById(R.id.txtDicePoint1);
        txtDicePoint2 = findViewById(R.id.txtDicePoint2);

        //Radio buttons
        radioGroup = findViewById(R.id.radioGroup);
        selectedDiceOne = findViewById(R.id.selectedDiceOne);
        selectedDiceTwo = findViewById(R.id.selectedDiceTwo);
        selectedBoth = findViewById(R.id.selectedBoth);

        //edittext for enter dice two's sides
        diceTwoValue = findViewById(R.id.diceTwoValue);
        defaultSide = findViewById(R.id.defaultSide);

        localData(); // check sharedPreference data
        radioButtons(); //manage radio button
        getDice2Side(); // check for side in edittext
    }

    private void getDice2Side() {

        if (!TextUtils.isEmpty(diceTwoValue.getText().toString())){
            diceTwoSide = Integer.valueOf(diceTwoValue.getText().toString());
        }
    }

    private void radioButtons() {

        // radio button select which dice should roll and accordingly data  will change

        radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            switch (checkedId) {
                case R.id.selectedDiceOne:
                    maxClick = 0;
                    selectedDice = 1;
                    clearOld();

                    editor.putInt(SELECTED_DICE,selectedDice);
                    editor.apply();
                    break;

                case R.id.selectedDiceTwo:
                    maxClick = 0;
                    selectedDice = 2;
                    clearOld();

                    editor.putInt(SELECTED_DICE,selectedDice);
                    editor.apply();
                    break;

                case R.id.selectedBoth:
                    maxClick = 0;
                    selectedDice = 0;
                    clearOld();

                    editor.putInt(SELECTED_DICE,selectedDice);
                    editor.apply();
                    break;
            }
        });
    }

    private void clearOld() {
        // clear all data from everywhere

        txtDicePoint1.setText("");
        txtDicePoint2.setText("");

        editor.putString(DICE_ONE_POINT,null);
        editor.putString(DICE_TWO_POINT,null);
        editor.putString(DICE_ONE_LAST_POINT,"4");
        editor.putString(DICE_TWO_LAST_POINT,"10");
        editor.apply();
    }

    private void localData() {

        //create database object
        editor = getSharedPreferences(DICE_ROLLING_DATABASE, MODE_PRIVATE).edit();

        //get SharedPreferences and check if data is available or not
        SharedPreferences prefs = getSharedPreferences(DICE_ROLLING_DATABASE, MODE_PRIVATE);

        if (prefs!=null){

            diceTwoSide = prefs.getInt(NUMBER_OF_SIDES_FOR_DICE2,12);
            if (diceTwoSide!=12){
                defaultSide.setText("(sides 1 to "+diceTwoSide+")");
                diceTwoValue.setText(String.valueOf(diceTwoSide));
            }

            String diceOnePoint = prefs.getString(DICE_ONE_POINT,null);
            String diceTwoPoint = prefs.getString(DICE_TWO_POINT,null);
            txtDicePoint1.setText(diceOnePoint);
            txtDicePoint2.setText(diceTwoPoint);

            String diceBox1Point = prefs.getString(DICE_ONE_LAST_POINT,"4");
            String diceBox2Point = prefs.getString(DICE_TWO_LAST_POINT, String.valueOf(diceTwoSide));
            txtDiceOne.setText(diceBox1Point);
            txtDiceTwo.setText(diceBox2Point);

            maxClick = prefs.getInt(MAX_CLICK,0);
            selectedDice = prefs.getInt(SELECTED_DICE,0);

            if (selectedDice == 1){
                selectedDiceOne.setChecked(true);
            } else if (selectedDice == 2){
                selectedDiceTwo.setChecked(true);
            } else  {
                selectedBoth.setChecked(true);
            }

        }

    }

    public void rollDice(View view) {
        // this method is called when press `Roll` button
        if (maxClick == 6){
            Toast.makeText(this, "Please change dice for new result", Toast.LENGTH_SHORT).show();
            return;
        }

        maxClick++;


        if (selectedDice == 1) { // if "Dice 1" selected than called this block
            int n = new Random().nextInt(9);
            txtDiceOne.setText(String.valueOf(n));
            txtDicePoint1.append(n +", ");

            editor.putString(DICE_ONE_POINT,txtDicePoint1.getText().toString());
            editor.putString(DICE_ONE_LAST_POINT,String.valueOf(n));


        } else if (selectedDice == 2) { // if "Dice 2" selected than called this block
            int n = new Random().nextInt(diceTwoSide - Low) + Low;
            txtDiceTwo.setText(String.valueOf(n));
            txtDicePoint2.append(n +", ");

            editor.putString(DICE_TWO_POINT,txtDicePoint2.getText().toString());
            editor.putString(DICE_TWO_LAST_POINT,String.valueOf(n));

        } else { // if Dice both selected than called this block
            int n = new Random().nextInt(9);
            int second = new Random().nextInt(diceTwoSide - Low) + Low;

            txtDiceOne.setText(String.valueOf(n));
            txtDiceTwo.setText(String.valueOf(second));

            txtDicePoint1.append(n +", ");
            txtDicePoint2.append(second +", ");

            editor.putString(DICE_ONE_POINT,txtDicePoint1.getText().toString());
            editor.putString(DICE_TWO_POINT,txtDicePoint2.getText().toString());

            editor.putString(DICE_ONE_LAST_POINT,String.valueOf(n));
            editor.putString(DICE_TWO_LAST_POINT,String.valueOf(second));
        }

        editor.putInt(MAX_CLICK,maxClick);
        editor.apply();
    }

    public void clearAll(View view) {
        // this is clear all data from sharedPreference or views
        editor.clear();

        selectedDice = 1;
        maxClick = 0;
        diceTwoSide = 12;

        txtDicePoint1.setText("");
        txtDicePoint2.setText("");
        txtDiceOne.setText("4");
        txtDiceTwo.setText(String.valueOf(diceTwoSide));
        selectedDiceOne.setChecked(true);

        diceTwoValue.setText("");
        defaultSide.setText("(default sides 1 to 12)");

    }

    public void onSaveSides(View view) {

        // this method is save number of sides value for side two

        if (!TextUtils.isEmpty(diceTwoValue.getText().toString())){
            diceTwoSide = Integer.valueOf(diceTwoValue.getText().toString());
            editor.putInt(NUMBER_OF_SIDES_FOR_DICE2,diceTwoSide);
            editor.apply();

            defaultSide.setText("(sides 1 to "+diceTwoSide+")");
            Toast.makeText(this, "Save", Toast.LENGTH_SHORT).show();

        } else  {
            Toast.makeText(this, "Please enter number of sides", Toast.LENGTH_SHORT).show();
        }
    }
}